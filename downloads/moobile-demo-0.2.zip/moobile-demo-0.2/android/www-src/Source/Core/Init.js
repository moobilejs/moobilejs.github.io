/*
---

name: Init

description:

license:

authors:
	- Jean-Philippe Dery (jeanphilippe.dery@gmail.com)

requires:

provides:
	- Init

...
*/

var ViewController = {
	Component: {},
	Event: {}
};
